"""Check that each response-0N.txt matches result-0N.json and logs/dra_style_pilot.jsonl.
Run from the package root:  python3 evidence/pilot/verify_responses.py
Compares text only (line endings ignored). It does NOT check against Gemini or the screenshots; see RESPONSE_VERIFICATION.md."""
import json
from pathlib import Path

def norm(s):
    return (s or "").replace("\r\n", "\n").strip()

rows = [json.loads(l) for l in Path("logs/dra_style_pilot.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
assert len(rows) == 8, "expected 8 log rows"
ok = True
for i, log in enumerate(rows, 1):
    file_text = norm(Path(f"evidence/pilot/response-0{i}.txt").read_text(encoding="utf-8"))
    result = json.loads(Path(f"evidence/pilot/result-0{i}.json").read_text(encoding="utf-8"))
    recorded = norm(result.get("response"))
    logged = norm(log.get("response"))
    placeholder = file_text == "[No response recorded]"
    if placeholder:
        same = recorded == "" and logged == ""
        note = "placeholder file; result and log have no response"
    else:
        same = file_text == recorded == logged
        note = "file == result == log"
    ok &= same
    print(f"response-0{i}: {'OK ' if same else 'DIFF'} {log['status']:<34} {note}")
print("ALL CONSISTENT" if ok else "MISMATCH FOUND")
