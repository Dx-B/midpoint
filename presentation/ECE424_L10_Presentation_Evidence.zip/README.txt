Team Vibe code | Paper L10 | ECE 424
Nathan Choke, Philip Guan, William Zhang
Presentation and evidence snapshot prepared November 21, 2026.
Presentation slot: November 30, 10:20–10:30 a.m. Eastern.
Slides/evidence deadline: November 24, 11:59 p.m. Eastern.

FILES
ECE424_L10_Slides.pdf: frozen four-slide presentation.
ECE424_L10_Demonstration.mp4: local 720p narrated demonstration.
Speaker_Notes.txt: presenter scripts.
evidence/: exact repository snapshot, commit
15b15d49eb4ae879164754cef8fdcd7fe6a6fffb
https://github.com/Dx-B/midpoint/tree/15b15d49eb4ae879164754cef8fdcd7fe6a6fffb

DEMO SETUP AND RUN
Open the slide PDF and play the MP4 in a standard local media player.
The PDF does not embed a playable video. Keep the MP4 beside it.
Enable audio and test projection before the session. No API key or paid
model account is needed to replay this recording.
Introduce the question, play the recording, pause at the prediction screen
if desired, then show the results page and closing slide.
Allow approximately 6–7 minutes plus questions within the ten-minute slot.

EVIDENCE GUIDE
evidence/<repository>/evidence/pilot/completed-reruns.json:
complete rerun prompts, replies and links.
evidence/<repository>/evidence/pilot/screenshot-02.png,
screenshot-04.png and screenshot-06.png: completed rerun captures.
evidence/<repository>/evidence/scoring/final.csv and RUBRIC.md:
human scoring for the original eight attempts, with rubric definitions.
evidence/<repository>/logs/dra_style_pilot_check.json:
saved matrix/provenance check, not an effectiveness measurement.
harness.py contains the user-message defense reminder.
evidence/scoring/score_tools.py validates human-assigned records and agreement.
Original scores and later reruns represent different attempts.
Reruns await independent scoring. Three original attempts were interrupted.
The classroom terminal walkthrough is a labeled prepared simulation.
The movie animates recorded logs; playback makes zero live model calls.

FORMAT AND SUBMISSION
The assignment requires slides and frozen evidence; this package supplies both.
A separate draft asks staff whether a five-minute narrated segment is acceptable.
That format has not been explicitly approved in the provided course messages.
No email has been sent and no Canvas submission has been made.
The final report/artifact submission due December 15 remains a separate deliverable.
